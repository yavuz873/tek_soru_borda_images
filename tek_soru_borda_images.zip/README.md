
# Tek Soru Borda – Görselli Sürükle-Bırak
- Adaylar **görsel kart** olarak listelenir (thumbnail + isim)
- Sürükle-bırak ile 1→5 sıralarsın; puanlar 5,4,3,2,1
- Sonuçlar /results, CSV /export.csv, JSON /results.json
- Aynı tarayıcıdan tek oy için cookie koruması
- Admin reset: /reset?token=DEGIS_TIR

## Görseller
`static/img/` klasöründeki dosya adlarını `app.py` içindeki `img` alanına yaz.
